<html>
<body>
<h2>Products</h2>
<ul>
<% String[] p = (String[]) request.getAttribute("products");
   for (String s : p) { %>
   <li><%= s %></li>
<% } %>
</ul>
</body>
</html>
