<html>
<body>
<h2>Login</h2>
<form method="post" action="login">
  Username: <input name="username"/><br/>
  Password: <input type="password" name="password"/><br/>
  <button type="submit">Login</button>
</form>
${error}
</body>
</html>
