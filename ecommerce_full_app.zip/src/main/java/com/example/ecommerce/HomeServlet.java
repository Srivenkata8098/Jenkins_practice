package com.example.ecommerce;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class HomeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setAttribute("products", new String[]{"Laptop","Phone","Headphones"});
        req.getRequestDispatcher("home.jsp").forward(req, resp);
    }
}
